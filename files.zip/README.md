# Alternative-Data Signal Discovery Engine

A research tool that systematically tests whether external, non-price signals —
macro data, commodity prices, competitor stock movements, Google Trends, and
industry-specific alternative data — have any **stable, statistically significant
predictive relationship** with a stock's forward returns.

It is built to answer one question honestly: *for a given stock, which external
signals actually lead its returns, at what time lag, with what statistical
significance — and are those relationships stable enough to be useful?*

> **On what this project is (and isn't).** This is a **signal-testing and
> market-efficiency research tool**, not a trading system or a price predictor.
> Run across large-cap stocks, its central finding is that most candidate
> signals are noise, and the few that clear significance thresholds are
> **unstable over time** — their correlation flips sign across market regimes.
> That is a legitimate, well-documented empirical result about market
> efficiency, and reporting it honestly is the point of the tool. See
> [Findings](#findings) below.

---

## What it does

The engine runs in two stages.

**1. Data pipeline** (`data_pipeline.py`) — for any ticker, dynamically assembles
a signal matrix from multiple sources:
- **Price & forward returns** (1w / 2w / 1m / 3m) from Yahoo Finance
- **Macro factors** from FRED (rates, inflation, unemployment, VIX, USD, oil, etc.)
- **Sector context** (sector ETF + S&P 500)
- **Competitor prices**, discovered *dynamically* via a three-stage system —
  build a candidate universe (S&P 500 + sector-ETF holdings + Russell 1000),
  filter by exact Yahoo industry tag, then rank by price correlation. A quality
  gate falls back to an industry preset only when the dynamic pool is unreliable.
- **Google Trends** search-interest series
- **Industry-specific alternative data** (`industry_signals.py`) — a rule-based
  layer reads the company's business description and maps it to relevant data
  concepts (e.g. an airline → jet fuel, air-travel demand, TSA throughput),
  then pulls those series. No industries are hard-coded into the decision;
  concepts are matched from the description.

**2. Signal engine** (`signal_engine.py`) — for every signal in the matrix:
- Tests correlation with forward returns across **7 lags** (1–63 days)
- Computes **statistical significance** (p-values)
- Measures **rolling 6-month correlation stability** — the most important check
- Classifies each signal (Strong / Moderate / Weak / Noise)
- Builds a composite score and a full visual report

---

## Example output

Each run produces a report like these. Note the recurring pattern: a large
fraction of signals are **Noise**, and even the significant ones are flagged
**unstable** by the rolling-correlation panel.

**Apple (AAPL)** — macro-driven; ~50% of signals noise:

![AAPL report](images/AAPL_signals.png)

**Southwest Airlines (LUV)** — the most interesting case. Competitor airline
prices (AAL, ALK) lead LUV returns at a ~21-day lag more strongly than any
macro factor — while jet fuel, the "obvious" airline driver, does **not** clear
significance (airlines hedge fuel, and the market prices it in quickly):

![LUV report](images/LUV_signals.png)

**Alphabet (GOOG)** — ~93% noise; a near-total null result:

![GOOG report](images/GOOG_signals.png)

**Ford (F)** — mixed macro/industry signals, all weak:

![F report](images/F_signals.png)

---

## Findings

Running the engine across several large-cap stocks produced consistent,
honest conclusions:

1. **Most signals are noise.** Typically 50–93% of tested signals fail to reach
   statistical significance for any given stock.
2. **Significant signals are unstable.** The rolling-correlation analysis shows
   relationships that hold in some periods and reverse in others (e.g. an
   unemployment→AAPL correlation swinging between +0.8 and −0.6). A signal that
   flips sign is not tradeable.
3. **What drives a stock is stock-specific.** Large-cap tech (AAPL, GOOG) is
   dominated by macro signals; the airline (LUV) is dominated by intra-industry
   competitor dynamics. There is no universal signal set.
4. **"Obvious" relationships often fail the test.** Jet fuel did not
   significantly lead Southwest's returns, which is consistent with fuel hedging
   and efficient pricing — a good example of the tool disproving an intuition.
5. **Correlations top out around 0.3–0.4** — far too weak, and far too unstable,
   to constitute a trading edge at daily resolution.

**Interpretation.** These results are consistent with the academic literature:
within-industry lead–lag effects are real but largely dissipate at daily
resolution, and single-stock daily-frequency signal hunting does not produce a
durable edge for efficiently-traded large caps. The value of this project is the
**rigorous testing framework** and the **honest negative result**, not a
profitable signal.

---

## Setup

```bash
git clone https://github.com/<your-username>/signal-discovery.git
cd signal-discovery
pip install -r requirements.txt
```

Create a `.env` from the template and add your free FRED key:

```bash
cp .env.example .env
# then edit .env and set FRED_API_KEY
```

- FRED key (free): https://fred.stlouisfed.org/docs/api/api_key.html

## Usage

```bash
# 1. Build the signal matrix for a ticker (writes TICKER_signals.csv)
python data_pipeline.py

# 2. Analyse it and produce the report
python signal_engine.py
```

Enter a ticker when prompted (e.g. `AAPL`, `LUV`, `GOOG`, `F`). The signal
engine loads the cached CSV if present, otherwise rebuilds it.

---

## Methodology notes & honest limitations

- **Lag testing** shifts each signal forward relative to returns so that a
  signal at day *t* is tested only against returns at *t + lag* (forward-looking,
  to avoid trivially using future information). This shift logic is the single
  most important thing to verify before trusting any number here.
- **Daily resolution** is a real limitation — lead–lag effects are known to be
  stronger intraday and to fade at daily frequency.
- **Single-stock, absolute returns.** A more robust design would test signals
  against a stock's performance *relative to a basket of 20–30 peers*, which
  strips out market-wide noise and is more likely to surface genuine structure.
  This is the natural next iteration.
- **Correlation is not causation**, and with many signals × many lags, some
  significant results are expected by chance — hence the emphasis on stability
  over raw significance.

## Repository layout

```
data_pipeline.py     # builds the multi-source signal matrix for a ticker
industry_signals.py  # rule-based industry-specific alternative-data layer
signal_engine.py     # correlation, significance, stability, composite, plots
images/              # example output reports
requirements.txt
.env.example
```

## Tech

Python · pandas · NumPy · SciPy · scikit-learn-style workflow · Matplotlib ·
seaborn · yfinance · FRED API · pytrends
